export class User {
    _id: any;
    fname: any;
    lname: any;
    username: any;
    password: any;
    addressLine1: any;
    addressLine2: any;
    city: any;
    pincode: any;
    state: any;
    country: any;
}
